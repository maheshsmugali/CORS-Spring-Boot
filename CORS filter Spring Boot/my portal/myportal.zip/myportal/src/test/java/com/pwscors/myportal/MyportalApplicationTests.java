package com.pwscors.myportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
