package com.pwscors.myportalclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyportalClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyportalClientApplication.class, args);
	}

}
